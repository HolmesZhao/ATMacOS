class BundleEx { }

public
extension Bundle {
    /// 当前所在 bundle
    static var current: Bundle {
        let bundleEx = Bundle(for: BundleEx.self)
        if let path = bundleEx.path(forResource: "PrintKit", ofType: "bundle"),
            let bundle = Bundle(path: path) {
            return bundle
        }
        return bundleEx
    }
}
