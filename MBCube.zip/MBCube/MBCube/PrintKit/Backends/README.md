向打印机发送数据，封装打印机的连接方式。
BLE 打印机实现 BLEDeviceProtocol 协议中的方法
云打印实现 CloudDeviceProtocol 协议中的方法
局域网打印实现 LanDeviceProtocol 协议中的方法
