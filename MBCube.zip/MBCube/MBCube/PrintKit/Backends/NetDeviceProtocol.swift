//
//  NetDeviceProtocol.swift
//  MBCube
//
//  Created by junbin on 2023/1/28.
//

import Foundation

/// 云打印通道
protocol NetDeviceProtocol {
    
    /// 配网
    /// - Parameters:
    ///   - ip: ip 地址
    ///   - sid: 网络 sid
    ///   - pwd: 密码
    ///   - complete: 结果回调
    func configNetwork(_ ip: String, _ ssid: String, _ pwd: String, _ complete:((_ isSuccess:Bool) -> Void))
    
    /// 连接打印机
    func connectByNet()
    
    /// 断开连接
    func disconnectByNet()
}

extension NetDeviceProtocol {
    
    func configNetwork(_ ip: String, _ ssid: String, _ pwd: String, _ complete:((_ isSuccess:Bool) -> Void)){}
        
    func connectByNet(){}
    
    func disconnectByNet(){}
    
}
