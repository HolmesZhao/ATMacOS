//
//  LanDeviceProtocol.swift
//  MBCube
//
//  Created by junbin on 2023/1/29.
//

import Foundation

protocol LanDeviceProtocol {
    
    /// 配网
    /// - Parameters:
    ///   - ip: ip 地址
    ///   - sid: 网络 sid
    ///   - pwd: 密码
    ///   - complete: 结果回调
    func configRouter(_ ip: String, _ ssid: String, _ pwd: String, _ complete:((_ isSuccess:Bool) -> Void)?)
    
    /// 连接打印机
    func connectByLan()
    
    /// 断开连接
    func disconnectByLan()
    
}

extension LanDeviceProtocol {
    
    func configRouter(_ ip: String, _ ssid: String, _ pwd: String, _ complete:((_ isSuccess:Bool) -> Void)){}
        
    func connectByLan(){}
    
    func disconnectByLan(){}
    
}

