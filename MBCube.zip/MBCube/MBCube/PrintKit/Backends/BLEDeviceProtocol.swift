//
//  BLEDeviceProtocol.swift
//  MBCube
//
//  Created by junbin on 2023/1/28.
//

import Foundation

/// 蓝牙通道
protocol BLEDeviceProtocol {
    
    /// 连接打印机
    func connect()
    
    /// 断开连接
    func disconnect()
}

extension BLEDeviceProtocol {
    
    func connect(){}
    
    func disconnect(){}
    
}
