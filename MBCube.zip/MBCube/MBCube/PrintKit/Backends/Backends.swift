//
//  Backends.swift
//  MBCube
//
//  Created by 苏志成 on 2022/12/29.
//

import Foundation

// 通道类型
public enum Backends : Int {
    case GATT // 蓝牙扫描
    case NET // 云端请求
    case LAN // 局域网
    case MFI
    case USB
}

