//
//  PaperLayout.swift
//  MBCube
//
//  Created by junbin on 2023/2/10.
//

import Foundation

/// 纸张布局
public class PaperLayout {
    
    /// 纸张物理宽度，单位 mm
    public var width: Int?
    
    /// 纸张物理高度，单位 mm
    public var height: Int?
    
    /// 上边距，单位 mm
    public var top: Int?
    
    /// 下边距，单位mm
    public var bottom: Int?
    
    /// 左边距，单位 mm
    public var left: Int?
    
    /// 右边距，单位 mm
    public var right: Int?
    
}
