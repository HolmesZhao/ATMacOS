//
//  PaperHandling.swift
//  MBCube
//
//  Created by junbin on 2023/2/10.
//

import Foundation

/// 纸张处理
public class PaperHandling {
    
    /// 打印页数范围
    public var pageRange : PageRange?
    
    /// 纸张方向
    public var orientation: Orientation?
    
    /// 翻转
    public var flip: Flip?
    
    /// 逐页打印
    public var collate: Collate?
    
    /// 纸张顺序， "normal" | "reverse"
    /// normal 表示正向，reverse 表示反向
    public var order: Order?
    
    /// 待打印的张数
    public var sheetToPrint: SheetToPrint?
    
    /// 打印方式
    public var printType: PrintType?
    
    /// 单双页
    public var duplex: Duplex?
    
    public init(orientation: Orientation? = nil, flip: Flip? = nil, collate: Collate? = nil, order: Order? = nil, sheetToPrint: SheetToPrint? = nil, printType: PrintType? = nil, duplex: Duplex? = nil) {
        self.orientation = orientation
        self.flip = flip
        self.collate = collate
        self.order = order
        self.sheetToPrint = sheetToPrint
        self.printType = printType
        self.duplex = duplex
    }
}
