//
//  JobAttributesOptions.swift
//  Alamofire
//
//  Created by junbin on 2023/2/10.
//

import Foundation

public enum Duplex {
    case simplex // 表示单页打印
    case duplexShortEdge // 表示自动双页短边
    case duplexLongEdge // 表示自动双页长边
    case manualDuplexShortEdge // 表示手动双页短边
    case manualDuplexLongEdge // 表示自动双页长边
}

public enum Collate {
    case collate // 逐份
    case nonCollate // 非逐份
}

public enum Orientation {
    case portrait // 竖向
    case landscape // 横向
}

public enum Flip {
    case normal // 正常
    case vertical // 竖直
    case horizontally // 水平
}

public enum Order {
    case normal // 正常
    case reverse // 反向
}

public enum SheetToPrint {
    case odd // 仅奇数页
    case even // 仅偶数页
    case all // 所有页
}

public enum PrintType {
    case continuous // 连续打印
    case pagination // 分页打印
}

public enum ColorMode {
    case color // 表示彩色
    case monochrome // 表示黑白
    case grayscale // 表示灰阶
}

public enum Feeder {
     case auto // 表示机器自动决定
     case manual_tray // 表示手动进纸盒
     case auto_tray // 表示自动进纸盒
 }

public enum Scaling {
    case auto // 自动适配
    case fill // 拉伸填充
    case fit  // 按比例适配
}
