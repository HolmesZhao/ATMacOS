//
//  ScanAttributes.swift
//  MBCube
//
//  Created by junbin on 2023/1/31.
//

import Foundation

/// 扫描任务属性
public class ScanAttributes {
    
    /// 颜色设置， "color"|"monochrome"|"grayscale"
    /// color 表示彩色，monochrome 表示黑白， grayscale 表示灰阶
    public var colorMode: Int?
    
    /// 解析度（单位：dpi）
    public var resolution: Int?
    
    /// 支持的纸张物理尺寸列表，单位 mm，取值为 12| 57 | 79 | 110 | 210
    public var paperSize: Int?
    
}
