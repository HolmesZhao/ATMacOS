//
//  PageRange.swift
//  MBCube
//
//  Created by junbin on 2023/2/10.
//

import Foundation

/// 页面范围
public class PageRange {
    
    /// start 表示起始页索引，start 从 0 开始取值
    public var start: Int?
    
    /// 打印页码范围，count 表示从 start 开始，打印多少个页面
    public var count: Int?
    
}
