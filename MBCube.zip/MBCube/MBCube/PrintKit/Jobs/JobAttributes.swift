//
//  JobAttributes.swift
//  MBCube
//
//  Created by junbin on 2023/1/28.
//

import Foundation

/// 打印任务属性
public class JobAttributes {
    
    /// 打印份数
    public var copies: Int = 1
    
    /// 打印浓度，取值范围 1 - 100
    public var density: Int = 92
    
    /// 颜色设置
    public var colorMode: ColorMode = .monochrome

    /// 打印速度，取值范围 1- 100
    public var speed: Int = 90
    
    /// 走一段空白纸能力，取值为 ture | false
    public var blank: Bool = false
    
    /// 切刀能力，取值为 ture | false
    /// 打印完成之后，进行一次切割操作
    public var cut: Bool = false

    /// 打印分割线能力，取值为 ture | false
    public var bottomLine: Bool = false
    
    /// 缩放方式
    public var scaling: Scaling = .auto
    
    /// 纸张来源
    public var feeder: Feeder = .auto
    
    /// 页面布局
    public var paperLayout: PaperLayout?
    
    /// 纸张处理
    public var paperHandling: PaperHandling?
    
    /// 打印任务状态
    public var state: JobEvent?
    
    public init() {
        
    }

}
