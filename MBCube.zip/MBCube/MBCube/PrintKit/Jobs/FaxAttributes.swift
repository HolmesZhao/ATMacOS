//
//  FaxAttributes.swift
//  MBCube
//
//  Created by junbin on 2023/1/31.
//

import Foundation

/// 传真任务属性
public class FaxAttributes {
    
}
