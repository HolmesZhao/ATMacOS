//
//  DocumentFormatterProtocol.swift
//  Paperang
//
//  Created by junbin on 2022/12/20.
//  Copyright © 2022 Hoho. All rights reserved.
//

import Foundation

/// 获取格式化后的图片
protocol FormatterProtocol {
    
    /// 获取文件数据
    /// - Returns: data
    func getRawData() -> Data?
    
    /// 获取格式化后的图片
    /// - Returns: UIImage 对象
    func getFormattedImage() -> UIImage?
    
    /// 文件路径
    /// - Returns: 字符串路径
    func getPath() -> String
}
