//
//  ImageFormatter.swift
//  MBCube
//
//  Created by junbin on 2023/1/31.
//

import Foundation

/// 图片格式转换器，将图片处理成适合的打印图片
public class ImageFormatter: FormatterProtocol {
    
    public var imagePath: String?
    
    func getRawData() -> Data? {
        return nil
    }
    
    func getFormattedImage() -> UIImage? {
        return nil
    }
    
    func getPath() -> String {
        return imagePath ?? ""
    }
    
    public init(imagePath: String? = nil) {
        self.imagePath = imagePath
    }
}
