//
//  DocumentFormatter.swift
//  MBCube
//
//  Created by junbin on 2023/1/31.
//

import Foundation

/// 文档格式转换器，将文档处理成适合的打印格式
public class DocumentFormatter: FormatterProtocol {
    
    private var filePath: String?
    
    func getRawData() -> Data? {
        return nil
    }
    
    func getFormattedImage() -> UIImage? {
        return nil
    }
    
    func getPath() -> String {
        return filePath ?? ""
    }
}
