//
//  Cube.DocumentEvent.swift
//  MBCube
//
//  Created by junbin on 2023/1/31.
//

import Foundation

// 3000 复印文档
// 3001 扫描文档
// 3002 传真文档

/// 文档事件
public class DocumentEvent {
    /// 状态代码
    public var code: Int
    
    /// 文档url
    public var url: String?
    
    /// 文档数据
    public var data: Data?
    
    public init(code: Int, url: String? = nil, data: Data? = nil) {
        self.code = code
        self.url = url
        self.data = data
    }
}
