//
//  PrintStatus.swift
//  MBCube
//
//  Created by miao on 2023/2/23.
//

import UIKit

public enum PrinterErrorState: Int {
    case lowToner = -1                   // 粉盒粉量低
    case endOfLifeDrum = -2              // 鼓组件寿命将尽
    case lowTonerAndEndOfLifeDrum = -3   // 粉盒粉量低及鼓组件寿命将尽
    case printingPaused = 2              // 打印暂停
    case frontCoverOpen = 10             // 打印机前盖被打开
    case rearCoverOpen = 11              // 打印机后盖被打开
    case tonerCartridgeMissing = 12      // 粉盒未安装
    case incorrectTonerCartridge = 13    // 粉盒类型不匹配
    case endOfLifeToner = 14             // 粉盒寿命已尽
    case outOfPaperAutoTray = 15         // 自动进纸盒缺纸
    case paperJam = 19                   // 中间卡纸
    case paperJamAtExit = 20             // 出纸处卡纸
    case paperJamAtDuplexer = 21         // 双面打印单元处卡纸
    case drumCartridgeMissing = 24       // 鼓组件未安装
    case incorrectDrumCartridge = 27     // 鼓组件类型不匹配
    case mismatchedPaperTray = 222       // 纸张来源与实际进纸不匹配错误
    case endOfLifeFuser = 30             // 鼓组件寿命已尽
    case internalError = 32              // 打印机发生内部故障
    case manualFeedTrayEmpty = 162       // 手动进纸失败或缺纸
    case autoFeedTrayError = 172         // 自动进纸盒进纸失败
    case paperJamAtInput = 182           // 进纸处卡纸
}
