//
//  JobEvent.swift
//  MBCube
//
//  Created by junbin on 2023/2/9.
//

import Foundation

//    3000: "任务排队或者挂起中",
//    3001: "任务正在处理中",
//    3002： "任务已停止",
//    3003： "任务已取消",
//    3004： "任务已中断",
//    3005： "任务已完成"
//    3006： "任务已失败"

public class JobEvent {
    /// 状态代码
    public var code: Int
    
    /// 状态描述
    public var message: String

    init(code: Int, message: String) {
        self.code = code
        self.message = message
    }
}
