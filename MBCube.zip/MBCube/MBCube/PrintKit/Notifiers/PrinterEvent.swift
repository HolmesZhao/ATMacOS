//
//  PrinterEvent.swift
//  MBCube
//
//  Created by junbin on 2023/1/28.
//

import Foundation

//    1000 : "缺纸",
//    1001 : "缺墨",
//    1002 : "缺碳粉",
//    1003 : "切刀异常",
//    1004 : "上盖打开",
//    1005 : "前盖打开",
//    1006 : "后盖打开",
//    1007 : "鼓异常",
//    1008 : "过热",
//    1009 : "网络离线",
//    1010 : "低电量",
//    1011 : "待机",
//    1012 : "休眠",
//    1013 : "关机",
//    2000 : "网络在线",
//    2001 : "打印中",
//    2002 : "扫描中",
//    2003 : "复印中",
//    2004 : "传真中",
//    2005 : "自我检查中",

/// 打印机状态
public class PrinterEvent {
    /// 状态代码
    public var code: Int
    
    /// 状态描述
    public var message: String
    
    init(code: Int, message: String) {
        self.code = code
        self.message = message
    }
}

