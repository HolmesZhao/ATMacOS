//
//  PrintScheduler.swift
//  Paperang
//
//  Created by junbin on 2022/12/20.
//  Copyright © 2022 Hoho. All rights reserved.
//

import Foundation
import lld
import MMLog

/// 打印机制造商
public enum PrinterMaker {
    case Pantum // 奔图
    case Paperang // 喵宝
}

/// 打印调度
public class PrintScheduler {
    
    /// 单例
    public static let shared = PrintScheduler()
    
    /// 打印机列表
    public var usingPrinters: [PrinterDevice]?
    
    /// 代理
    public var delegate: PrintSchedulerDelegate?
    
    /// 是否在持续搜索设备中
    public var deviceSearch = false
    
    /// 日志控制
    /// - Parameter isEnable: bool
    public func setPrintLog(_ enable: Bool) {
        // TODO 启动一个标志位,后续所有的操作都进行日志记录
    }
    
    /// 搜索设备
    /// - Parameter maker: 设备厂商
    public func searchPrinters(_ maker: PrinterMaker) {
        if maker == .Pantum {
            searchPantumPrinters()
        }
    }
    
    /// 连接打印机
    /// - Parameter device: 打印机
    /// - Returns: 是否开始连接
    public func connectPrinter(_ device: PrinterDevice) -> Bool {
        if device is PantumPrinter {
            return connectPantumPrinter(device)
        }
        return false
    }
    
    /// 断开打印机
    /// - Parameter device: 打印机
    /// - Returns: 是否开始断开
    public func disconnectPrinter(_ sn: String) -> Bool {
        /// TODO 根据不同的设备
        return true
    }
    
    /// 配置局域网
    /// - Parameters:
    ///   - ip: ip
    ///   - ssid: wifi 名称
    ///   - pwd: 密码
    ///   - complete: 完成回调
    public func configRouter(_ sn:String, _ ip: String, _ ssid: String, _ pwd: String, _ complete:((_ isSuccess:Bool) -> Void)?) {
        // TODO 局域网设备配网
        let pantumPrinter = PantumPrinter(sn: "")
        pantumPrinter.configRouter(ip, ssid, pwd, complete)
    }
    
    /// 配置公网
    /// - Parameters:
    ///   - sn: sn
    ///   - ip: ip 地址
    ///   - sid: 网络 sid
    ///   - pwd: 密码
    ///   - complete: 结果回调
    func configNetwork(_ sn: String, _ ip: String, _ ssid: String, _ pwd: String, _ complete:((_ isSuccess:Bool) -> Void)) {
        // TODO 云设备配网
    }
    
    /// 打印
    /// - Parameters:
    ///   - sn: sn
    ///   - jobAttr: 任务属性对象
    ///   - imageFormatters: 数据适配器
    ///   - complete: 完成回调
    ///   - failure: 失败回调
    /// - Returns: 任务 Id
    public func printJob(_ sn: String,
                         _ jobAttr: JobAttributes?,
                         _ imageFormatters: [ImageFormatter],
                         _ complete: (() -> Void)?,
                         _ failure: ((_ code : Int, _ message : String?) -> Void)?) -> String {
        let pantumPrinter = PantumPrinter(sn: sn)
        return pantumPrinter.printJob(jobAttr: jobAttr, imageFormatters: imageFormatters, complete: complete, failure: failure)
    }
    
    
    /// 切换打印通道
    /// - Parameters:
    ///   - _sn: sn
    ///   - type: 打印通道类型
    public func changeBackend(_sn: String, _ type:  Backends) {
        // TODO 根据不同的通道类型，切换打印机的不同通道
    }
    
    /// 打印机是否在线
    /// - Parameter device: 打印机
    /// - Returns: 是否在线
    public func isPrinterOnline(_ device: PrinterDevice) -> Bool {
        if device is PantumPrinter {
            return isPantumOnline(device.ip ?? "", device.sn)
        }
        return false
    }
    
    /// 获取打印机能力
    /// - Parameter _sn: 设备 SN
    /// - Returns: 设备能力描述对象
    public func getPrinterCapability(_sn: String) -> PrinterCapability? {
        let printerCap = PrinterCapability()
        return printerCap
    }
    
    public struct DeviceStatus {
        public var title: String = ""
        public var context: String = ""
        public var codeId: Int = 0
    }
    
    
    /// 返回打印机当前状态
    /// - Parameter device: 打印机
    /// - Returns: 打印机状态
    public func getDeviceStatus(_ device: PrinterDevice)-> DeviceStatus {
        
        guard let modulePath = Bundle.current.path(forResource: "PrintStatus", ofType: "plist") else {
            return DeviceStatus()
        }
        guard  let dic = NSDictionary(contentsOfFile: modulePath) else {
            return DeviceStatus()
        }
        
        let statusCode = getPantumModelType()
        var deviceStatus = DeviceStatus()
        
        let defaultArray:[[String:Any]] = dic["default"] as? [[String:Any]] ?? []
        let kindArray:[[String:Any]] = dic[(device.kind ?? "error")] as? [[String:Any]] ?? []
        
        for info in defaultArray {
            if let title:String = info["title"] as? String,
               let content:String = info["content"] as? String,
               let codeId:Int = info["code"] as? Int {
                if codeId == statusCode {
                    deviceStatus = DeviceStatus(title: title,context:content,codeId:codeId)
                }
            }
        }
        
        for info in kindArray {
            if let title:String = info["title"] as? String,
               let content:String = info["content"] as? String,
               let codeId:Int = info["code"] as? Int {
                if codeId == statusCode {
                    deviceStatus = DeviceStatus(title: title,context:content,codeId:codeId)
                }
            }
        }
        
        return deviceStatus
        
    }
    
}

/// 奔图设备
extension PrintScheduler: LLDSLPDelegate, LLDPrintDelegate {
    
    public func isPantumOnline(_ printerIP: String, _ printerSN: String) -> Bool {
        let isOnline = LLD.shared.isDeviceOnline(printerIP: printerIP, printerSN: printerSN)
        return isOnline
    }
    
    public func getPantumModelType()-> Int {
        let model_type = LLD.shared.getDeviceModelType()
        guard let status = LLD.shared.getDeviceStatus() as? Dictionary<String, Int> else {
            return 0
        }
        
        guard let statusCode = status["statusCode"] as? Int else {
            return 0
        }
        
        MMLog.log("pantum🐌SDK --statusCode:\(statusCode)", prefix: .connectSDK)
        return statusCode
    }
    
    private func connectPantumPrinter(_ device: PrinterDevice) -> Bool {
        return LLD.shared.setDevice(name: device.name ?? "",
                                    model: device.name ?? "",
                                    conType: 0,
                                    conIDHandle: device.ip ?? "",
                                    jbigflag: false)
    }
    
    private func searchPantumPrinters() {
        // 开始搜索局域网内机器
        
        if deviceSearch {
            return
        }
        deviceSearch = true
        
        DispatchQueue.global().async { [weak self] in
            LLD_SLP.shared.set_SLP_Stop()
            LLD_SLP.shared.lldSlpDelegate = self
            LLD.shared.printDelegate = self
            
            MMLog.log("MMPantumCheckUDPOnLine get_Devices_SLP_Init \(Date())", prefix: .connectSDK)
            
            guard LLD_SLP.shared.get_Devices_SLP_Init() else {
                return
            }
            
            MMLog.log("MMPantumCheckUDPOnLine get_Devices_SLP_Init end  \(Date())", prefix: .connectSDK)
            
            self?.delegate?.didStartSearch()
            self?.deviceSearch = false
        }
    }
    
    public func SlpFineNewDevice(_ lld_slp: lld.LLD_SLP, _ data: String?) {
        guard let dataStr = data else { return }
        guard let jsonData = dataStr.data(using: .utf8) else { return }
        guard let dict = try? JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers) as? NSDictionary else { return }
        
        guard let printIp = dict["printIp"] as? String else { return }
        guard let printName = dict["printName"] as? String else { return }
        guard let printerSN = dict["printerSN"] as? String else { return }
        let pantumDevice = PantumPrinter(sn: printerSN)
        pantumDevice.ip = printIp
        pantumDevice.name = printName
        delegate?.didFindNewDevice(device: pantumDevice)
    }
    
    public func SlpEndSearch(_ lld_slp: lld.LLD_SLP) {
        delegate?.didEndSearch()
    }
    
    public func lldPrintStartJob(_ lld: lld.LLD) {
        delegate?.didStartJob()
    }
    
    public func lldPrintStartPage(_ lld: lld.LLD, pageIndex: UInt32) {
        
    }
    
    public func lldPrintJobProgress(_ lld: lld.LLD, jobProgress: UInt32) {
        
    }
    
    public func lldPrintEndPage(_ lld: lld.LLD, pageIndex: UInt32) {
        
    }
    
    public func lldPrintEndJob(_ lld: lld.LLD) {
        delegate?.didEndJob()
    }
}
