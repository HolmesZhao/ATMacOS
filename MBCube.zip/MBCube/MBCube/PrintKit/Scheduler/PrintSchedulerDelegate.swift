//
//  PrintSchedulerDelegate.swift
//  MBCube
//
//  Created by junbin on 2023/2/3.
//

import Foundation

/// 搜索回调接口
public protocol PrintSchedulerDelegate: AnyObject {

    /// 开始搜索设备
    func didStartSearch()
    
    /// 结束搜索设备
    func didEndSearch()
    
    /// 查找到新设备
    /// - Parameter device: PrinterDevice 对象
    func didFindNewDevice(device: PrinterDevice)
    
    /// 开始打印任务
    func didStartJob()
    
    /// 完成打印任务
    func didEndJob()
    
}
