//
//  FaxProtocol.swift
//  MBCube
//
//  Created by junbin on 2023/1/29.
//

import Foundation

/// 传真能力
protocol FaxProtocol {
    
    /// 传真文档事件回调
    /// - Parameter event: 文档信息
    func onReceiveDocumentEvent(event: DocumentEvent)
    
}

extension FaxProtocol {
    
    func onReceiveDocumentEvent(event: DocumentEvent){}
    
}
