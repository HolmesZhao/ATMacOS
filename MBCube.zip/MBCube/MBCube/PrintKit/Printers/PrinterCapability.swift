//
//  PrinterAttributes.swift
//  Alamofire
//
//  Created by junbin on 2023/2/10.
//

import Foundation

/// 传真能力
public class FaxSupport {
    
    public var colorMode: ColorMode?
    
    public var resolution: [Int]?
    
    public var paper: [Int]?

}

/// 扫描能力
public class ScanSupport {
    
}

/// 打印能力
public class PrintSupport {
    
    public var colorMode: ColorMode?
    
    public var duplex: Duplex?
    
    public var collate: Collate?
    
    public var paper: [Int]?
    
    public var feeder: Feeder?
}

/// 打印机能力
public class PrinterCapability {
    
    /// 打印能力
    public var print: PrintSupport?
    
    /// 扫描能力
    public var scan: ScanSupport?
    
    /// 传真能力
    public var fax: FaxSupport?
}
