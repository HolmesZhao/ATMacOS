//
//  CopyProtocol.swift
//  MBCube
//
//  Created by junbin on 2023/1/29.
//

import Foundation

/// 复印能力
protocol CopyProtocol {
    
    /// 复印文档事件
    /// - Parameter event: 文档信息
    func onReceiveDocumentEvent(event: DocumentEvent)
}

extension CopyProtocol {
    
    func onReceiveDocumentEvent(event: DocumentEvent){}
    
}
