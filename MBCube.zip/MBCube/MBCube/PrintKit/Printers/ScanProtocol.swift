//
//  ScanProtocol.swift
//  MBCube
//
//  Created by junbin on 2023/1/29.
//

import Foundation

/// 扫描能力
protocol ScanProtocol {
    
    /// 扫描文档事件回调
    /// - Parameter event: 文档信息
    func onReceiveDocumentEvent(event: DocumentEvent)
    
    /// 取消扫描
    func cancelScan()
    
    /// 开始扫描
    func startScan()
    
}

extension ScanProtocol {
    
    func onReceiveDocumentEvent(event: DocumentEvent){}
    
    func cancelScan(){}
    
    func startScan(){}
}
