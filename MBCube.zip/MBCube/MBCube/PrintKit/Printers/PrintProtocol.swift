//
//  JobProtocol.swift
//  MBCube
//
//  Created by junbin on 2023/1/29.
//

import Foundation

/// 打印能力
protocol PrintProtocol {
    
    /// 获取打印机能力
    /// - Returns: 打印机能力
    func getPrinterCapability() -> PrinterCapability?
    
    /// 使用文档创建打印任务，
    /// - Parameter jobAttr: JobAttributes 对象
    /// - Returns: job Id
    func printJob(_ jobAttr: JobAttributes?) -> String
    
    /// 创建一个空的打印任务
    /// - Parameter jobAttr: JobAttributes 对象
    /// - Returns: job Id
    func createJob(_ jobAttr: JobAttributes?) -> String
    
    /// 发送文档给打印任务
    /// - Parameters:
    ///   - jobId: 打印任务 id，来自 createJob
    ///   - path: 文档路径
    ///   - complete: 结果回调
    func sendDocument(_ jobId: String, _ path: String, _ complete:((_ jobId: String, _ isSuccess: Bool) -> Void))
    
    /// 查询打印任务列表
    /// - Returns: 打印任务列表
    func getJobs() -> [JobAttributes]?
    
    /// 获取打印任务详情
    /// - Parameter jobId: 来自 createJob 接口的返回值或者来自 printJob 接口的返回值
    /// - Returns: 任务属性对象 JobAttributes
    func getJobAttributes(_ jobId: String) -> JobAttributes?
    
    /// 取消打印任务
    /// - Parameters:
    ///   - jobId: 来自 createJob 接口的返回值或者来自 printJob 接口的返回值
    ///   - complete: 结果回调
    func cancelJob(_ jobId: String, _ complete:((_ jobId: String, _ isSuccess: Bool) -> Void))
    
    
    /// 打印机状态变化回调接口
    /// - Parameters:
    ///   - event: PrinterEvent
    ///   - device: Device
    func onDeviceStateChange(_ event: PrinterEvent, _ device: Device)
    
    /// 执行打印机自检任务
    func printTest()
    
    /// 获取打印机状态
    /// - Returns: 打印机状态对象
    func getDeviceState() -> PrinterEvent?
    
    /// 查询 Job 任务列表状态
    /// - Returns: JobEvent
    func getJobsState() -> JobEvent?
    
    /// 任务状态回调接口
    /// - Parameters:
    ///   - event: JobEvent
    ///   - job: JobAttributes
    ///   - device: Device
    func onJobStateChange(_ event: JobEvent, _ job: JobAttributes, _ device: Device)
    
}

/// PrintProtocol 默认实现
extension PrintProtocol {
    
    func getPrinterCapability() -> PrinterCapability? {
        return nil
    }
    
    func printJob(_ jobAttr: JobAttributes?) -> String {
        return "0"
    }
    
    func createJob(_ jobAttr: JobAttributes?) -> String {
        return "0"
    }
    
    func sendDocument(_ jobId: String, _ path: String, _ complete: ((String, Bool) -> Void)) {
        
    }
    
    func getJobs() -> [JobAttributes]? {
        return nil
    }
    
    func getJobAttributes(_ jobId: String) -> JobAttributes? {
        return nil
    }
    
    func cancelJob(_ jobId: String, _ complete: ((String, Bool) -> Void)) {}
        
    func printTest() {}
    
    func getDeviceState() -> PrinterEvent? {
        return nil
    }
    
    func getJobsState() -> JobEvent? {
        return nil
    }
    
    func onDeviceStateChange(_ event: PrinterEvent, _ device: Device) {}
        
    func onJobStateChange(_ event: JobEvent, _ job: JobAttributes, _ device: Device) {}

}
