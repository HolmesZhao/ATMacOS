//
//  PrinterDevice.swift
//  MBCube
//
//  Created by junbin on 2023/1/28.
//

import Foundation

/// 打印机
/// 打印设置可以通过 JobAttributes 进行配置
public class PrinterDevice : Device {
    
    /// 支持的纸张物理尺寸列表，单位 mm，取值为 12| 57 | 79 | 110 | 210
    public var paperSize: [Int]?
    
    /// 支持的纸张类型列表，取值为"standard" | "roll" | "fold"
    /// standard 为默认类型，表示标准纸张类型，roll 表示卷纸，fold 表示折叠纸
    public var paperType: [String]?
    
    /// 支持的分辨率列表
    public var documentResolution: [Int]?

    /// 支持的文档类型列表，文档类型使用 MIME 表示
    public var documentFormat: [String]?
    
    /// 设备状态
    public var deviceState: PrinterEvent?
    
}

