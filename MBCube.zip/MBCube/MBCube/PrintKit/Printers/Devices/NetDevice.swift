//
//  NetPrinterDevice.swift
//  MBCube
//
//  Created by junbin on 2023/1/31.
//

import Foundation

/// 硬件设备
public class NetPrinterDevice: PrinterDevice {
    /// wifi
    public var ssid: String?
    
    /// 上线时间
    public var connectTime: String?
    
    /// 下线时间
    public var disconnectTime: String?
    
    public override init(sn: String) {
        super.init(sn: sn)
    }
    
}
