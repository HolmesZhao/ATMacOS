//
//  PantumPrinter.swift
//  MBCube
//
//  Created by junbin on 2023/1/28.
//

import Foundation
import lld

public class PantumPrinter: PrinterDevice {
    
    public var ssid: String?
    
    public var netIp: String?
    
    public var password: String?
    
    public var isUDPOnline: Bool?
    
}

extension PantumPrinter: LanDeviceProtocol {
    
    func configRouter(_ ip: String, _ ssid: String, _ pwd: String, _ complete:((_ isSuccess: Bool) -> Void)?){
        let isSuccess = LLD.shared.utilSetDeviceWifi(ip: ip,
                                                     ssid: ssid,
                                                     password: pwd,
                                                     mode: e_security_mode_wpa2)
        complete?(isSuccess)
    }
    
    func setPrintLog(_ enable: Bool){
        
    }
    
    func connectByLan(){
        
    }
    
    func disconnectByLan(){
        
    }
    
    func changeBackend(_ type:  String){
        
    }
}


extension PantumPrinter: PrintProtocol {
    
    func getDefaultJobAttributes() -> JobAttributes {
        return JobAttributes()
    }
    func getPrinterAttributes() -> PrinterDevice? {
        return nil
    }
    
    func printJob(jobAttr: JobAttributes?,
                  imageFormatters: [ImageFormatter],
                  complete: (() -> Void)?,
                  failure: ((_ code : Int, _ message : String?) -> Void)?) -> String {
        print("==== printJob ====")
        LLD.shared.enqueuePrintFileClear()
        var tempJobAttr = jobAttr
        if tempJobAttr == nil {
            tempJobAttr = getDefaultJobAttributes()
        }
//        if tempJobAttr?.paperHandling?.duplex == .manualDuplexLongEdge ||
//            tempJobAttr?.paperHandling?.duplex == .manualDuplexShortEdge {
//            var oddList = [String]()
//            var evenList = [String]()
//            for (i,imageFormatter) in imageFormatters.enumerated() {
//                if i%2 == 0 {
//                    oddList.append(imageFormatter.getPath())
//                } else {
//                    evenList.append(imageFormatter.getPath())
//                }
//            }
//
//            /// 首先传入奇数页
//            for (_,path) in oddList.enumerated() {
//                guard LLD.shared.enqueuePrintFile(filePath: path) != false else {
//                    /// 打印任务状态
//                    //    3000: "任务排队或者挂起中",
//                    //    3001: "任务正在处理中",
//                    //    3002： "任务已停止",
//                    //    3003： "任务已取消",
//                    //    3004： "任务已中断",
//                    //    3005： "任务已完成"
//                    failure?(3004,"任务已中断")
//                    return "0"
//                }
//            }
//
//            /// 分割标识
//            _ = LLD.shared.enqueuePrintFile(filePath: "#manual_duplex_odd_end#")
//
//            /// 再传入偶数页，偶数列需要倒序
//            for (_,path) in evenList.enumerated().reversed() {
//                guard LLD.shared.enqueuePrintFile(filePath: path) != false else {
//                    failure?(3004,"任务已中断")
//                    return "0"
//                }
//            }
//        } else {
//            for imageFormatter in imageFormatters {
//                guard LLD.shared.enqueuePrintFile(filePath: imageFormatter.getPath()) != false else {
//                    failure?(3004,"任务已中断")
//                    return "0"
//                }
//            }
//        }
        
        for imageFormatter in imageFormatters {
            guard LLD.shared.enqueuePrintFile(filePath: imageFormatter.getPath()) != false else {
                failure?(3004,"任务已中断")
                return "0"
            }
        }
        
        _ = LLD.shared.enqueuePrintFile(filePath: nil)
        
        // 设置打印参数
        var duplex = "simplex"
        switch tempJobAttr?.paperHandling?.duplex {
        case .simplex:
            duplex = "simplex"
            
        case .duplexShortEdge:
            duplex = "duplex_short_edge"
            
        case .duplexLongEdge:
            duplex = "duplex_long_edge"
            
        case .manualDuplexLongEdge:
            duplex = "manual_duplex_long_edge"
            
        case .manualDuplexShortEdge:
            duplex = "manual_duplex_short_edge"
            
        case .none:
            duplex = "simplex"
            
        }
        
        var collate = "collate"
        switch tempJobAttr?.paperHandling?.collate {
            case .collate:
                collate = "collate"
            case .nonCollate:
                collate = "non-collate"
            case .none:
                collate = "collate"
        }
        
        var feeder = "auto"
        switch tempJobAttr?.feeder {
        case .auto:
            feeder = "auto"
        case .manual_tray:
            feeder = "manual_tray"
        case .auto_tray:
            feeder = "auto_tray"
        case .none:
            feeder = "auto"
        }
        _ = LLD.shared.setPrintSetting(num_of_copies: tempJobAttr?.copies ?? 1,
                                   mode: "bw",
                                   duplex: duplex,
                                   collate: collate,
                                   paper: "A4",
                                   feeder: feeder,
                                   halftone_index: 0x00)
        
        /// 根据枚举值做提示，枚举值之后根据产品需求重新定义
        let print_result = LLD.shared.startPrint()
        if print_result != e_print_result_success {
            
            switch print_result {
                
            case e_print_result_cancel_from_host:
                failure?(3006,"任务被取消")
            case e_print_result_error_connection_failed:
                failure?(3006,"连接打印机失败")
            case e_print_result_error_connection_interrupt:
                failure?(3006,"连接打印机失败")
            case e_print_result_error_device_not_set:
                failure?(3006,"打印机设置失败")
            case e_print_result_error_invalid_context:
                failure?(3006,"打印内容异常")
            case e_print_result_error_invalid_param:
                failure?(3006,"打印参数异常")
            case e_print_result_error_enqueue_timeout:
                failure?(3006,"打印任务超时")
            default:
                failure?(3006,"任务已失败")
            }
            
        } else {
            complete?()
        }

        return "0"
    }
    
    
    func printJob(_ jobAttr: JobAttributes?) -> String {
        LLD.shared.enqueuePrintFileClear()
        var tempJobAttr = jobAttr
        if tempJobAttr != nil {
        } else {
            tempJobAttr = getDefaultJobAttributes()
        }
        
        if tempJobAttr?.paperHandling?.duplex == .manualDuplexLongEdge ||
            tempJobAttr?.paperHandling?.duplex == .manualDuplexShortEdge {
            
        }
        return "0"
    }
    
    func createJob(_ jobAttr: JobAttributes?) -> String {
        return "0"
    }
    
    func sendDocument(_ jobId: String, _ path: String, _ complete: ((String, Bool) -> Void)) {
        
    }
    
    func getJobs() -> [JobAttributes]? {
        return nil
    }
    
    func getJobAttributes(_ jobId: String) -> JobAttributes? {
        return nil
    }
    
    func cancelJob(_ jobId: String, _ complete: ((String, Bool) -> Void)) {
        
    }

    
    func printTest() {
        
    }
    
    func getDeviceState() -> PrinterEvent? {
        return nil
    }
    
    func getJobsState() -> JobEvent? {
        return nil
    }
    
}
