//
//  MBCube.swift
//  MBCube
//
//  Created by 苏志成 on 2022/12/27.
//

import Foundation

public enum Cube {
    
}


