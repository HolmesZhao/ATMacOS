//
//  CubeDevice.swift
//  MBCube
//
//  Created by junbin on 2023/1/28.
//

import Foundation

public class Device {
    
    /// 设备 SN
    public var sn: String = ""
    
    /// 设备类型
    public var kind: String?
    
    /// 型号
    public var makeAndModel: String?
    
    /// 名字
    public var name: String?
    
    /// 位置
    public var location: String?
    
    /// 支持的语言
    public var languages: [String]?
    
    /// mac 地址
    public var mac: String?
    
    /// ip 地址
    public var ip: String?
    
    ///  资源定位地址
    public var uri: String?
    
    /// 固件版本
    public var version: String?
    
    /// 喵宝协议版本
    public var ppVersion: String?
    
    /// 电量
    public var battery: Int?
    
    public init(sn: String) {
        self.sn = sn
    }
}

